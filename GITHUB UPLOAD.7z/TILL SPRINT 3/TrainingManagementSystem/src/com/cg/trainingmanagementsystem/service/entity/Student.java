package com.cg.trainingmanagementsystem.service.entity;

import java.util.*;

/**
 * 
 */
public class Student {

	/**
	 * Default constructor
	 */
	public Student() {
	}

	/**
	 * 
	 */
	private String studentId;

	/**
	 * 
	 */
	private String studentName;

	/**
	 * 
	 */
	private TrainingProgram trainingProgram;


}