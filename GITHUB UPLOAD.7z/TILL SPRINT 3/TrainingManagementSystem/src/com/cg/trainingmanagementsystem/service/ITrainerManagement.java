package com.cg.trainingmanagementsystem.service;

import java.sql.SQLException;
import java.util.*;

import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.service.enumv.Skills;

/**
 * 
 */
public interface ITrainerManagement {

	/**
	 * @throws ProgramException 
	 * 
	 */
	//public boolean addSkillsToTrainer( String trainerId, Set<String> skill) throws  ProgramException;

	/**
	 * @throws SQLException 
	 * @throws ProgramException 
	 * @throws SkillNotMatchedException 
	 * @throws NoSkillInDatabaseException 
	 * 
	 */
	//public boolean delSkillsToTrainer( String trainerId, Set<String> skills)throws  ProgramException;

	/**
	 * 
	 */
	public Trainer getTrainerDetails(Trainer trainer);

	/**
	 * 
	 */
	public HashSet<Trainer> getAllTrainers();

	/**
	 * 
	 */
	public boolean createTrainer(Trainer trainer);

	boolean addSkillTrainers(String trainerID, Set<String> skills)
			throws ProgramException;

	boolean delSkillTrainers(String trainerID, Set<String> skills)
			throws ProgramException;

}