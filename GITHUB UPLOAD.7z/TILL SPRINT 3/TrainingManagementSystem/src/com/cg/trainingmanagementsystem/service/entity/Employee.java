package com.cg.trainingmanagementsystem.service.entity;

import java.util.Date;

public class Employee {

	/**
	 * Default constructor
	 */
	public Employee() {
	}

	/**
	 * 
	 */
	private String empName;

	/**
	 * 
	 */
	private String empId;

	/**
	 * 
	 */
	private Date dateOfJoining;

}