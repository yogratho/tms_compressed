package com.cg.trainingmanagementsystem.service.impl;

import java.util.*;

import com.cg.trainingmanagementsystem.service.IFeedbackOperation;
import com.cg.trainingmanagementsystem.service.entity.Feedback;
import com.cg.trainingmanagementsystem.service.entity.TrainingProgram;

/**
 * 
 */
public class FeedbackOperationImpl implements IFeedbackOperation {

	@Override
	public Feedback viewFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Feedback viewDefaulterList(TrainingProgram trainingProgram, Feedback feedback) {
		// TODO Auto-generated method stub
		return null;
	}

	
}