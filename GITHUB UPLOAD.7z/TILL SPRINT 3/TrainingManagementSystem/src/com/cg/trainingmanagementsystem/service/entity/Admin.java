package com.cg.trainingmanagementsystem.service.entity;

public class Admin extends Employee {

	/**
	 * Default constructor
	 */
	public Admin() {
	}

}