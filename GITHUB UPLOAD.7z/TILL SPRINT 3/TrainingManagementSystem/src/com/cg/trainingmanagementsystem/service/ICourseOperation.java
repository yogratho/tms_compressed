package com.cg.trainingmanagementsystem.service;

import java.util.*;

import com.cg.trainingmanagementsystem.service.entity.Course;

/**
 * 
 */
public interface ICourseOperation {

	/**
	 * 
	 */
	public boolean addCourse(Course course);

	/**
	 * 
	 */
	public boolean deleteCourse(Course course);

	/**
	 * 
	 */
	public boolean modifyCourse(Course course);

	/**
	 * 
	 */
	public HashSet<Course> getAllCourse();

	/**
	 * 
	 */
	public Course getCourseDetails();

}