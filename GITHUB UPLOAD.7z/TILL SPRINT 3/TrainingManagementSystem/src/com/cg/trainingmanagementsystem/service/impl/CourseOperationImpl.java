package com.cg.trainingmanagementsystem.service.impl;

import java.util.*;

import com.cg.trainingmanagementsystem.service.ICourseOperation;
import com.cg.trainingmanagementsystem.service.entity.Course;

/**
 * 
 */
public class CourseOperationImpl implements ICourseOperation {

	@Override
	public boolean addCourse(Course course) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCourse(Course course) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modifyCourse(Course course) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public HashSet<Course> getAllCourse() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Course getCourseDetails() {
		// TODO Auto-generated method stub
		return null;
	}


}