package com.cg.trainingmanagementsystem.service.entity;

public class Feedback {

	/**
	 * Default constructor
	 */
	public Feedback() {
	}

	/**
	 * 
	 */
	private Student participant;

	/**
	 * 
	 */
	private TrainingProgram trainingProgram;

	/**
	 * 
	 */
	private int criteriaFirst;

	/**
	 * 
	 */
	private int criteriaSecond;

	/**
	 * 
	 */
	private int criteriaThird;

	/**
	 * 
	 */
	private int criteriaFourth;

	/**
	 * 
	 */
	private int criteriaFifth;



}