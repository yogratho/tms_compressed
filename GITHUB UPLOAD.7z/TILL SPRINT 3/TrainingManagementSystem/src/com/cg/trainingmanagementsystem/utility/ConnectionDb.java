package com.cg.trainingmanagementsystem.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDb {

	private static Connection connection;
	public static Connection getConnection()
	{
		if(connection==null)
		{
		try {
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","sys as sysdba", "system");
			
			
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		
		
		return connection;
	}
}
