package com.cg.trainingmanagementsystem.utility;

public class DbQueries {
	public static final String GET_SKILL_OF_TRAINER="delete from skill where employeeid=?";
	public static final String DELETE_PERTICULAR_TRAINER_SKILL=
			"delete from skill where employeeid=? and skill=?";
	public static final String SHOW_TRAINER_SKILL ="select employeeid,skill from (select e.employeeid, s.skill from employee e inner join skill s on e.employeeid=s.employeeid) where employeeid=?";
	public static final String ADD_PERTICULAR_TRAINER_SKILL = "insert into skill values(?,?)";
	public static final String 	CHECK_EXISTENCE="select employeeid from employee where employeeid=?";
	

}
