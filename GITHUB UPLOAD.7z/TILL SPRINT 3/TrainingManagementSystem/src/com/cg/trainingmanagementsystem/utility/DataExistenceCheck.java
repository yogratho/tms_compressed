package com.cg.trainingmanagementsystem.utility;

import java.util.Iterator;
import java.util.Set;

import com.cg.trainingmanagementsystem.collection.TrainerStaticDatabase;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.service.enumv.Skills;

public class DataExistenceCheck {
	
	public static boolean DataBaseExistenceCheck(String skill)
	{
		boolean response=false;
		
			
				for(Skills skillEnum: Skills.values())
				{
				if(skillEnum.name().equalsIgnoreCase(skill))
				{
				response=true;
				break;
				}
				}
				
				
		
return response;
}
}
