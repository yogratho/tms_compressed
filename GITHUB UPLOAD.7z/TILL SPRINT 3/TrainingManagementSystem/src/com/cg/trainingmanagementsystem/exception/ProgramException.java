package com.cg.trainingmanagementsystem.exception;

public class ProgramException extends Exception {

	public ProgramException(String message7) {
		super(message7);
	}
	

}
