package com.cg.trainingmanagementystem.ui;

import com.cg.trainingmanagementsystem.service.entity.Course;
import com.cg.trainingmanagementsystem.service.entity.Feedback;
import com.cg.trainingmanagementsystem.service.entity.Student;
import com.cg.trainingmanagementsystem.service.entity.TrainingProgram;

public class CoordinatorController {

	public CoordinatorController() {
	}

	private Course course;

	private TrainingProgram trainingProgram;

	private Student student;

	private Feedback feedback;

}