


package com.cg.trainingmanagementsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.cg.trainingmanagementsystem.dao.ICrudOperation;
import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.entity.Trainer;
import com.cg.trainingmanagementsystem.utility.ConnectionDb;
import com.cg.trainingmanagementsystem.utility.DbQueries;
import com.cg.trainingmanagementsystem.utility.ErrorMessages;

/**
 * 
 */
public class TrainerManagementDaoImpl implements ICrudOperation<Trainer> {
	public static Set<String> skilltest;
	public static Set<String> skilldel;

	@Override
	public boolean create(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Trainer retrieve(Trainer o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public HashSet<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return null;
	}

	// public class TrainerManagementDaoImpl implements ICrudOperation<Trainer>
	// {
	@Override
	public void trainerSkillDeletion(Trainer trainer, Set<String> skilllist)
			throws ProgramException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = ConnectionDb.getConnection();
			preparedStatement = connection
					.prepareStatement(DbQueries.DELETE_PERTICULAR_TRAINER_SKILL);
			for (String string : skilllist) {

				preparedStatement.setString(1, trainer.getTrainerId());
				preparedStatement.setString(2, string);

				preparedStatement.execute();
				connection.commit();

				System.out.println("Success....Skills after deletion of "+string+" are----");
				ICrudOperation iCrudOperation = new TrainerManagementDaoImpl();
				iCrudOperation.getTrainerSkills(trainer.getTrainerId());
			}

		} catch (SQLException e) {

			throw new ProgramException(ErrorMessages.MESSAGE7);
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				throw new ProgramException(ErrorMessages.MESSAGE11);
			}
		}
	}

	@Override
	public void trainerSkillAddition(Trainer trainer, Set<String> skilllist)
			throws ProgramException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = ConnectionDb.getConnection();
			preparedStatement = connection
					.prepareStatement(DbQueries.ADD_PERTICULAR_TRAINER_SKILL);
			for (String string : skilllist) {

				preparedStatement.setString(1, trainer.getTrainerId());
				preparedStatement.setString(2, string);

				preparedStatement.execute();
				connection.commit();

				System.out.println("Success....Skills after addition of "+string+" are----");
				ICrudOperation iCrudOperation = new TrainerManagementDaoImpl();
				iCrudOperation.getTrainerSkills(trainer.getTrainerId());
			}

		} catch (SQLException e) {

			throw new ProgramException(ErrorMessages.MESSAGE7);
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				throw new ProgramException(ErrorMessages.MESSAGE11);
			}
		}

	}

	@Override
	public void getTrainerSkills(String trainerId) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = ConnectionDb.getConnection();
			preparedStatement = connection
					.prepareStatement(DbQueries.SHOW_TRAINER_SKILL);
			preparedStatement.setString(1, trainerId);
			ResultSet resultSet = preparedStatement.executeQuery();
			Set<String> set = new HashSet<String>();
			while (resultSet.next()) {
				set.add(resultSet.getString(2));
			}
			for (String string : set)
				System.out.println(string);

		} catch (SQLException e) {

		}

	}

}