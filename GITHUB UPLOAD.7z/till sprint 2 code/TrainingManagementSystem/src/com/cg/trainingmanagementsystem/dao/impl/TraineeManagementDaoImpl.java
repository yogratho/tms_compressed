package com.cg.trainingmanagementsystem.dao.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.trainingmanagementsystem.dao.ICrudOperation;
import com.cg.trainingmanagementsystem.exception.ProgramException;
import com.cg.trainingmanagementsystem.service.entity.Skill;
import com.cg.trainingmanagementsystem.service.entity.Trainer;

public class TraineeManagementDaoImpl implements ICrudOperation<Trainer> {

	@Override
	public boolean create(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Trainer retrieve(Trainer o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Trainer o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public HashSet<Trainer> getAllTrainers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void trainerSkillDeletion(Trainer trainer, Set<String> skilllist)
			throws ProgramException {
		
		
	}

	@Override
	public void trainerSkillAddition(Trainer trainer, Set<String> skilllist)
			throws ProgramException {
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Skill skill=new Skill();
		skill.setEmployeeId(trainer.getTrainerId());
		List<String> skillarray=new ArrayList<String>();
		for(String string:skilllist)
			skillarray.add(string);
		skill.setSkill(skillarray.get(0));
		entityManager.persist(skill);
		entityManager.getTransaction().commit();;
		entityManagerFactory.close();
		entityManager.close();
		
		
		
	}

	@Override
	public void getTrainerSkills(String trainerId) {
		
		
	}

}
